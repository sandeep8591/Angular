import { Component } from '@angular/core';

@Component({
    selector : `emp-root`,
    templateUrl : `./app.empcomponent.html`,
})
export class EmpComponent{

    empId = 123;
    name = "sachin";
    image = "./assets/sachin.jpg";
    result:boolean = true;

    test():number{
        return 12345;
    }

}