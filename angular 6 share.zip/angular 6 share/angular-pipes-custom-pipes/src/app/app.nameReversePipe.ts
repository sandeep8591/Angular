import { PipeTransform, Pipe } from '@angular/core';

@Pipe({
    name : 'reversePipe'
})
export class ReversePipe implements PipeTransform{
    transform(value: string):string {
        
        let outString : string = "";

        for(let i=value.length-1;i>=0;i--){
            outString = outString+value.charAt(i);
        }
        return outString;
    }
    
}