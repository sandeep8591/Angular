import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmployeeComponent } from './app.employeeComponent';
import { ReversePipe } from './app.nameReversePipe';
import { ParamPipe } from './app.parampipe';


@NgModule({
  declarations: [
    AppComponent,EmployeeComponent,ReversePipe,ParamPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
