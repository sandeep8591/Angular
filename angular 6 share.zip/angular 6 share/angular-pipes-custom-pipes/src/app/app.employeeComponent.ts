import { Component } from '@angular/core';
import { Employee } from './employee';

@Component({
    selector : '<emp-selector>',
    templateUrl : `./app.employeecomponent.html`
})

export class EmployeeComponent{

    employees : Employee[] = [

        {
            empId : 111,
            name  : "pavan kumar",
            desig : "consultant",
            salary: 52000
        },
        {
            empId : 101,
            name  : "shanthi",
            desig : "Team Leader",
            salary: 82000
        },
        {
            empId : 11,
            name  : "siva krishna",
            desig : "manager",
            salary: 92000
        },
        {
            empId : 211,
            name  : "vijay krishna",
            desig : "software developer",
            salary: 55000
        },
    ]
}