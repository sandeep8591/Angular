import { PipeTransform, Pipe } from '@angular/core';

@Pipe({
    name : "paramPipe"
})
export class ParamPipe implements PipeTransform{
    transform(value: string, first:string, last:string):string {
        let out = `${first} ${value} ${last}`;
        return out;
    }
    
}