export class Employee{
    empId : number;
    name  : string;
    desig : string;
    salary: number;
}