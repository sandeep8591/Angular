import { Component } from '@angular/core';
import { Employee } from './app.employee';

@Component({
  selector: 'my-test',
  templateUrl: './app.testComponent.html',
  styleUrls :['./app.component.css']
  
  })
  
export class TestComponent {

  state:string = "TN";

  numbers:number[] = [1,2,34,45,5];
  
  employees:Employee[] = [
    {
      empId : 1234,
      empName : "pavan",
      desig : "trainer",
      salary : 34000
    },
    {
      empId : 1111,
      empName : "kumar",
      desig : "sr.trainer",
      salary : 56000
    },
    {
      empId : 2222,
      empName : "Mohammed",
      desig : "jr.trainer",
      salary : 25000
    },
  ]

}