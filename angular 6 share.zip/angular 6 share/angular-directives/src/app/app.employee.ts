export class Employee{
    empId : number;
    empName  : string;
    desig : string;
    salary : number;
}