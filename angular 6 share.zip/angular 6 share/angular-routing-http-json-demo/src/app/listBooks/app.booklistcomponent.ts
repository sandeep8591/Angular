import { Component } from '@angular/core';
import { BookService } from '../service/app.bookservice';

@Component({
    selector : 'list-root',
    templateUrl : './app.booklistcomponent.html',
    providers : [BookService]
})

export class ListBookDetailsComponent{

    title : string = "list page";
    bookList : any = [];

    constructor(private bookService: BookService){
        this.bookService.getBookDetails().subscribe(data => this.bookList = data,);
    }

    delete(i){
   
        var retVal = confirm("Are you sure you want to delete?");
        if( retVal == true ) {
          this.bookList.splice(i,1);
          alert('Book got deleted sucessfully...');  
           return true;
        } else 
            return false;
        }
}