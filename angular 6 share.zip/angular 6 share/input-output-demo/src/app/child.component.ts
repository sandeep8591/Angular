import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Employee } from './app.employee';

@Component({
    selector: 'app-child',
    templateUrl: `./app.childcomponent.html`,
})

export class ChildComponent {
    
    @Input() 
    fullname:string;

    @Output() 
    notify: EventEmitter<string> = new EventEmitter<string>();

    onclick(): void {
        this.notify.emit("message from child component");
    }
}