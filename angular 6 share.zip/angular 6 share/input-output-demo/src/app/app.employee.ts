export class Employee {
    firstName: string;
    lastName: string;
}