import { Component } from '@angular/core';
import { Employee } from './app.employee';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
})
export class AppComponent {
  title:string = "input-output-demo";

  emp:Employee = {firstName:"sudheer",lastName:"kumar"};

  onMyClick(msg:string):void{
    this.title = msg;
  }




}
