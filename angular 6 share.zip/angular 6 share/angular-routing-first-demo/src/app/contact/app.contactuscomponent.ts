import { Component } from '@angular/core';

@Component({
  selector: 'contact-root',
  templateUrl: './app.contactuscomponent.html',
 })
export class ContactUsComponent {
  title = 'contact';
}