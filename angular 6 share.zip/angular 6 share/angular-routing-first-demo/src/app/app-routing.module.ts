import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/app.homecomponent';
import { AboutComponent } from './about/app.aboutcomponent';
import { ContactUsComponent } from './contact/app.contactuscomponent';

const routes: Routes = [
{path:'',redirectTo:'home'},
{path:'home',component:HomeComponent},
{path:'about',component:AboutComponent},
{path:'contactUs',component:ContactUsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
