import { Component } from '@angular/core';

@Component({
  selector: 'about-root',
  templateUrl: './app.aboutcomponent.html',
})
export class AboutComponent {
  title = 'about page';
}