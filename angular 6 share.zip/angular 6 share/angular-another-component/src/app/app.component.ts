import { Component } from '@angular/core';
import { MobileService, Mobile } from './mobile.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'AssessmentParameters';
  mobList:any = [];
  constructor(private service:MobileService) { 

    this.service.getMobiles().subscribe(data => this.mobList = data,);
  }
  delete(i){
   
    var retVal = confirm("Are you sure you want to delete?");
    if( retVal == true ) {
      this.mobList.splice(i,1);
      alert('Mobile got deleted sucessfully...');  
       return true;
    } else return false;
    }
  

}
