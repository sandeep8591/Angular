import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class MobileService {

  url:string = "/assets/mobile/mobile.json";
  constructor(private http:HttpClient) { }
  mobList:any = [];
  getMobiles(){

  return this.http.get<Mobile>(this.url);
  
  }

}
export class Mobile{
  mobId:number;
  mobName:string;
  mobPrice:number;
}
